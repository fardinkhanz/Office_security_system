#include <lpc214x.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define RTC_ADDW 0xd0       //write rtc
#define RTC_ADDR 0Xd1      //read rtc
#define STA  (1<<5)       //Start Set/Clear bit
#define STO  (1<<4)       //Stop bit
#define SI   (1<<3)       //Serial Interrupt Flag Clear bit
#define AA   (1<<2)       //Assert Acknowledge Set/Clear bit
void init_serial(void);
void port_init_i2c(void);
void rtc_init(void);
void rtc_read(void);
//void delay(void);
void I2C1SendStop(void);
int  I2C1RX_Byte(void);
void I2C1SendStart(void);
void I2C1TX_Byte(unsigned char data);
int I2C1WaitForSI(void);
void setdatetime(void);
int  SECO, temp,  X,Y,Z,i;
char rxd_data[10];
void convert(int );

void convert (int a)
{
    X=a&0X0F ;      //contents of time and calender registers are in BCD format
  Y=a&0XF0 ;     // convert bcd to hex
  Y=Y>>4;
  Z=((Y*10)+X);
  }
void display()
{
    i=0;
 while (rxd_data[i] != '\0')
 {  
  while(!(U0LSR&0X20));
  U0THR = rxd_data[i];
  delay();
  i++  ;
 }
 U0THR='\t';
   U0THR='\n';
   }

void rtc_init(void)
{
   port_init_i2c();
   I2C1SendStart();
   I2C1TX_Byte(RTC_ADDW);    // slave address of rtc
   I2C1TX_Byte(0x07);    //control reg address of rtc
   I2C1TX_Byte(0x00);  //   to set control reg disable sqw out 
   I2C1SendStop();
}
 void setdatetime(void)
{
 I2C1SendStart();
 I2C1TX_Byte(RTC_ADDW);    // slave address of rtc
 I2C1TX_Byte(0x00);         //sec reg address
 I2C1TX_Byte(0x00);       // load sec value
 I2C1SendStop();
 }

  void rtc_read(void)
 {
   I2C1SendStart();
   I2C1TX_Byte(RTC_ADDW);    // slave address of rtc D0  MODE.
   I2C1TX_Byte(0x00);       // load sec value
   I2C1SendStop();
   I2C1SendStart();
   I2C1TX_Byte(RTC_ADDR);    // slave address of rtc  D1  MODE.
   SECO=  I2C1RX_Byte();      // read seconds from rtc
   convert(SECO);
   sprintf(rxd_data ,"sec:%d",Z); // convert hex to string 
   display();
  I2C1SendStop();
   }
  void I2C1SendStart(void)
{
 I2C1CONCLR = STA | STO | SI | AA; //Clear everything
 I2C1CONSET = STA; //Set start bit to send a start condition
 I2C1WaitForSI(); //Wait till the SI bit is set
}
int I2C1WaitForSI() //Wait till I2C1 block sets SI
{
 int timeout = 0;
 while ( !(I2C1CONSET & SI) ) //Wait till SI bit is set. This is important!
 {
  timeout++;
  if (timeout > 10000) return 0; //In case we have some error on bus
 }
 return  1; //SI has been set
}
 int  I2C1RX_Byte()
{
 I2C0CONSET = AA; //Send ACK to continue
 I2C1CONCLR = SI; //Clear SI to Start RX
 I2C1WaitForSI(); //wait till RX is finished
 return I2C1DAT;
}
void I2C1TX_Byte(unsigned char data)
{ I2C1DAT = data;
 I2C1CONCLR = STA | STO | SI; //Clear These to TX data
 I2C1WaitForSI(); //wait till TX is finished
}

 void init_serial()
{
 PINSEL0=0X00000005;
 U0LCR = 0x00000083;   //enable baud rate divisor loading and select the data format
 U0DLM  = 0x00; 
 U0DLL =  0x13;        //select baud rate 9600 bps
 U0LCR = 0x00000003;
 }

void port_init_i2c()
{
 PCONP |= (1 << 19);  //I2C 1 is powered
 PINSEL0 |= 0x30C00005; //P0.14 and P0.11 are set as SDA & SCL
  I2C1SCLH = 0x0018;      //100KHZ IS SELECTED
    I2C1SCLL = 0x0012;
 I2C1CONCLR=0X00;
 I2C1CONSET = 0x40;     //enable I2C
   
    }

void I2C1SendStop(void)
{
 int timeout = 0;
 I2C1CONSET = STO ; //Set stop bit to send a stop condition
 I2C1CONCLR = SI;
 while (I2C1CONSET & STO) //Wait till STOP is send. This is important!
 {
  timeout++;
  if (timeout > 10000) //In case we have some error on bus
  {
   printf("STOP timeout!\n");
   return;
  }
 }
}

int i2c(void)
{   unsigned char disp_arr[100] = "RTC DATA IS ";  
    unsigned int i;
 i=0;
 init_serial();
 rtc_init();
 setdatetime();
 while(1)
 {  
   for (i=0;i<11;i++)
  {
   while(!(U0LSR&0X20));
   U0THR = disp_arr[i];
  }
    
  rtc_read();  
  }
}
  /* void delay()
  {
  int j;
  for (j=0;j<20000;j++);
  }*/