#include <LPC21xx.H>
 #define DESIRED_COUNT	1000			// for 1sec
#define PRESCALER	11999
void InitTimer0(void);
void InitTimer0(void)
{
		 	
	T0PR=PRESCALER;
	T0MR0=DESIRED_COUNT;	//interrupt every 1 sec for interval = 1000
	T0MCR=3;		//interrupt and reset when counter=match
	T0TCR=2;		 //	reset timer
   
}



