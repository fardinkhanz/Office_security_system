#include<lpc21xx.h>

void delay(void);
void serial(void);
void check(int);
void check1(void);
unsigned char mg;

int main()
{

int x=0;
serial();

while("1")
{ 
	
	while(!(U0LSR & 0x01));
	mg=U0RBR;
  U0THR=mg;
	delay();

	if(U0THR==98)
	{
		x=U0THR;
	}
	else if(U0THR==118)
	{
		x=x+U0THR;
	}
	else if(U0THR==97)
	{
		x=x+U0THR;
		check(x);
	}
	else if(U0THR==99 || U0THR<=100 || U0THR>=101  || U0THR>=102  || U0THR>=103  || U0THR>=104  || U0THR>=105  || U0THR>=106  || U0THR>=107  || U0THR>=108  || U0THR>=109  || U0THR>=110  || U0THR>=111  || U0THR>=112  || U0THR>=113  || U0THR>=114  || U0THR>=115  || U0THR>=116  || U0THR>=117  || U0THR>=119  || U0THR>=120  || U0THR>=121  || U0THR>=122)
	{
		check1();
	}
}
}
void check(int x)
{
	unsigned char msg[]={" You Are Welcome!"};
	unsigned int i;
	if(x==313)
	{
		for(i=0;i<17;i++)
	{
	while(!(U0LSR & 0x20));
    U0THR=msg[i];
	}
	}
}
void check1()
{
	unsigned char msg1[]={"Get Out!!"};
	unsigned int i;
		for(i=0;i<9;i++)
	{
	while(!(U0LSR & 0x20));
    U0THR=msg1[i];
	}
}
void serial()
{
	PINSEL0=0X00000005;
	U0LCR= 0X83;
	U0DLL=0X61;
	U0LCR=0X03;
}

void delay()
{
	 unsigned int i;
	for(i=0;i<10000;i++);
}
