#include<lpc21xx.h>
void delay(void);
void InitTimer0(void);
void step(void)
{
  int x=1;
	PINSEL2=0x0010000;
	IO0DIR=0xf0000000;
	IO1DIR=0x00000000;
	//x=IOPIN1;
	//x=x & 0x00f00000;
  PINSEL0 = 0X00000000 ;			// Configure P0.16-p0.23 as GPIO
	IODIR0=0X00FFF000;
	InitTimer0();  					// initialise timer0 - 
	T0TCR = 0x01;					// start timer 
 	while(x!=0)
	{	//if(x==0x00100000)
		//{
			while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;	
			IO0SET=0x10000000;
			
		 }
		 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;	
			IO0CLR=0x10000000;
			

		 }
			 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
			IO0SET=0x20000000;
		}

	
			 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
			IO0CLR=0x20000000;
			}

	delay();
			 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
			IO0SET=0x40000000;
			}
	

			 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
			IO0CLR=0x40000000;
			}

			 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
			IO0SET=0x80000000;
			}
		 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
			IO0CLR=0x80000000;
			delay();
		//}
		//else
		//{delay();
  }
			 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
		
			IO0SET=0x80000000;
			}
		 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
			IO0CLR=0x80000000;
			}
	
	
	
		 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
	IO0SET=0x40000000;
			}
	
	
			 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
			IO0CLR=0x40000000;
			}
			 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
			IO0SET=0x20000000;
			}
		 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
			IO0CLR=0x20000000;
			}
			 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
			IO0SET=0x10000000;
			}
			 	while(!( T0IR==0x01));			   // wait for overflow
	   { T0IR=0x01;
			IO0CLR=0x10000000;
			delay();
			delay();
	delay();}
	delay();
	
		//}
	x=x-1;}
	}

