#include<lpc21xx.h>
#include<stdio.h>
void delay(void);
void step(void);
void extint0_ISR(void);

void extint0_ISR(void)
{
	PINSEL1=0x00000000;
	  delay();
	step();
		delay();
	EXTINT=0x00000001;
	VICVectAddr=0;
	
}
