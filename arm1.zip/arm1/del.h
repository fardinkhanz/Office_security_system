#include<lpc21xx.h>


void delay()
{
unsigned int i;
for(i=0;i<10000;i++);
}
