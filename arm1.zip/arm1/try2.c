#include<lpc21xx.h>
void buzzer(void);
void command(unsigned int);
void data(unsigned int);
void lcd(void);
void step(void);
void delay(void);
void serial(void);
void check(int);
void check1(void);
unsigned char mg;

int main()
{

  unsigned long int value,i;
	int x=0,y=4;
	unsigned int row0[4]={0x00ee0000,0x00ed0000,0x00eb0000,0x00e70000};
	unsigned int row1[4]={0x00de0000,0x00dd0000,0x00db0000,0x00d70000};
	unsigned int row2[4]={0x00de0000,0x00bd0000,0x00bb0000,0x00b70000};
	unsigned int row3[4]={0x007e0000,0x007d0000,0x007b0000,0x00770000};
	PINSEL2=0x00000000;
	IO1DIR =0XFFF0FFFF; 
	PINSEL1=0x00000000;
	IODIR0=0xf0ff0000;
	IOSET0=0XF0000000;
	while(y!=0)
	{
	IO1PIN=0x00ff0000;
	IOCLR1=0x00100000;
	value=IOPIN1;
	delay();
	value=value & 0x00ff0000;
	for(i=0;i<4;i++)
	{
	if(value==row0[3])
	{
	x=1;
	delay();
	delay();
	delay();
	delay();
	delay();
	}
	}
	if(x==1)
	{
			IO1PIN=0x00ff0000;
			IOCLR1=0x00200000;
			value=IOPIN1;
			delay();delay();
			value=value & 0x00ff0000;
			for(i=0;i<4;i++)
			{
			if(value==row1[2])
			{
			x=2;
			delay();
			delay();
			delay();
			delay();
			}
			}
			if(x==2)
			{
					IO1PIN=0x00ff0000;
					IOCLR1=0x00400000;
					value=IOPIN1;
					delay();
					delay();
					delay();
					delay();
					delay();
					delay();
					delay();
					delay();
					value=value & 0x00ff0000;
					for(i=0;i<4;i++)
					{
					if(value==row2[1])
					{
					x=3;
					delay();
					}
					}
					if(x==3)
					{
							IO1PIN=0x00ff0000;
							IOCLR1=0x00800000;
							value=IOPIN1;
							delay();
							delay();
							delay();
							delay();
							value=value & 0x00ff0000;
							for(i=0;i<4;i++)
							{
							if(value==row3[0])
							{
							x=4;
							delay();
							delay();
							delay();
							delay();
							}
							}
							if(x==4)
							{
								check(x);
							}
							else{
								check1();
							}
				  }
					else{
						check1();
					}
		  }
			else{
				check1();
			}
	}
	else{
		check1();
	}
	y--;
 }
////@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	

  while(!(U0LSR & 0x01));
  mg=U0RBR;
  U0THR=mg;
  delay();
	delay();
  delay();
	delay();
	delay();
	delay();
	delay();
  if(U0THR==1)
	{
		step();
	}
	else{
		step();
	}
}


void check(int x)
{
  unsigned char msg[]={" You Are Welcome!"};
  unsigned int i;
 
    for(i=0;i<17;i++)
    {
      while(!(U0LSR & 0x20));
       U0THR=msg[i];
    }  
		step(); //calling stepper
    delay(); delay(); delay(); delay(); delay();// calling lcd		
		lcd();// calling lcd 
}


void check1()
{
  unsigned char msg1[]={"Get Out!!"};
  unsigned int i;
   for(i=0;i<9;i++)
  {
     while(!(U0LSR & 0x20));
      U0THR=msg1[i];
  }
   buzzer();  //calling buzzer
}


void serial()
{
  PINSEL0=0X00000005;
  U0LCR= 0X83;
  U0DLL=0X61;
  U0LCR=0X03;
}

void delay()
{
unsigned int i;
for(i=0;i<10000;i++);
}


void lcd(void)
{
	unsigned char message[]= {"hello"};
	unsigned int c[]={0x30,0x30,0x20,0x20,0x28,0x01,0x06,0x0e,0x89};
	unsigned int i,j;
	PINSEL0=0X00000005;
	IO0DIR=0x000000fc;
	for(i=0;i<9;i++)
	{
		command(c[i]);
		delay();
	}
	while(1)
	{
		command(0x89);
		delay();
		for(j=0;j<5;j++)
		{
			data(message[j]);
			delay();
		}
		delay();
		command(0x10);
		delay();
	}
}


void command(unsigned int x)
{
	unsigned int y;
	y=x;
	y=y & 0x0f;
	IO0CLR=0x000000fc;
	IO0CLR=0x00000004;
	IO0SET=y;
	IO0SET=0x00000008;
	delay();
	IO0CLR=0x00000008;
	y=x;
	y=y & 0x0f;
	y=y<<4;
	IO0CLR=0x00000004;
	IO0SET=y;
	IO0SET=0x00000008;
	delay();
	IO0CLR=0x00000008;
}


void data(unsigned int a)
{
	unsigned int b;
	b=a;
	b=b & 0x0f;
	IO0CLR=0x000000fc;
	IO0SET=0x00000004;
	IO0SET=b;
	IO0SET=0x00000008;
	delay();
	b=a;
	b=b& 0x0f;
	b=b<<4;
	IO0CLR=0x000000fc;
	IO0SET=0x00000004;
	IO0SET=b;
	IO0SET=0x00000008;
	delay();
	IO0CLR=0x00000008;
}
void step(void)
{
  int x=100;
	PINSEL2=0x0010000;
	IO0DIR=0xf0000000;
	IO1DIR=0x00000000;
	//x=IOPIN1;
	//x=x & 0x00f00000;

 	while(x!=0)
	{	//if(x==0x00100000)
		//{
			IO0SET=0x10000000;
			delay();
			IO0CLR=0x10000000;
			delay();
			IO0SET=0x20000000;
			delay();
			IO0CLR=0x20000000;
			delay();
			IO0SET=0x40000000;
			delay();
			IO0CLR=0x40000000;
			delay();
			IO0SET=0x80000000;
			delay();
			IO0CLR=0x80000000;
			delay();
		//}
		//else
		//{
		delay(); delay(); delay(); delay(); delay();
			IO0SET=0x80000000;
			delay();
			IO0CLR=0x80000000;
			delay();
			IO0SET=0x40000000;
			delay();
			IO0CLR=0x40000000;
			delay();
			IO0SET=0x20000000;
			delay();
			IO0CLR=0x20000000;
			delay();
			IO0SET=0x10000000;
			delay();
			IO0CLR=0x10000000;
			delay();
		//}
   x=x-1;
	}

}

void buzzer(void)
{
	PINSEL0=0x00000000;
	IODIR0=0x00000200;    ///po.9 made output
	IOCLR0=0x00000200;
	while(1)
	{
		IOSET0=0x00000200;
		delay();
		IOCLR0=0x00000200;
		delay();
	}
} 
